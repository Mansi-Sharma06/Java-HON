package com.accenture.lkm.exception;

public class NoRecordFoundException extends Exception{
	
	public NoRecordFoundException(String str)
	{
		super(str);
	}
}
